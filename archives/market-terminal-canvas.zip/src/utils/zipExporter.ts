import JSZip from 'jszip';
import { WidgetConfig } from '../types';

export async function generateOfflineZipBundle(currentWidgets: WidgetConfig[]) {
  const zip = new JSZip();

  const readmeContent = `# TERMINAL CANVAS // Global Market Dashboard (Offline Edition)

## Overview
This bundle contains a self-contained, standalone single-file web application for global market monitoring.
It works directly in any modern web browser without needing a web server, Node.js, or internet connection.

## Features Included
1. **Global Indices**: Americas, Europe, and Asia-Pacific stock benchmarks with real-time simulated tick engine and sparklines.
2. **AI / Energy / Financials Heatmap**: Dynamic sector treemap with color-coded performance indicators (+5% green / -5% red).
3. **AAPL 60-Session Chart**: Interactive candlestick chart with Volume, Moving Averages (MA20, MA50), RSI, and MACD indicators.
4. **Precious Metals & Commodities**: Real-time spot prices for Gold, Silver, Platinum, Palladium, WTI Crude, Brent, Natural Gas, and Copper with Gold/Silver ratio calculations.
5. **World Session Clocks**: Live trading hours, market open/closed badges, and UTC overlap timelines for New York, London, Frankfurt, Tokyo, Hong Kong, and Sydney.
6. **Order Tape**: Live streaming execution order stream.
7. **Drag & Drop Canvas**: Re-order, resize, minimize, or close widgets with layout persistence saved directly to browser \`localStorage\`.

## How to Run
1. Unzip this package to any folder.
2. Double-click \`index.html\` to launch in Google Chrome, Microsoft Edge, Mozilla Firefox, or Apple Safari.
3. No server setup, terminal commands, or internet access required!

## Files Included
- \`index.html\` - Standalone application
- \`README.md\` - Instructions & Documentation
- \`config/layout_backup.json\` - Preset layout configuration backup

---
*Exported from Google AI Studio Terminal Canvas Engine*
`;

  const layoutJson = JSON.stringify(currentWidgets, null, 2);

  // Generate a stand-alone single file html that renders the terminal dashboard
  const standaloneHtml = `<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>TERMINAL // Global Market Canvas (Offline Edition)</title>
  <style>
    :root {
      --bg-color: #030407;
      --text-color: #10b981;
      --border-color: #1e293b;
      --card-bg: #090a0f;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: var(--bg-color);
      color: var(--text-color);
      font-family: 'Courier New', Courier, monospace;
      padding: 16px;
      overflow-x: hidden;
    }
    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 16px;
      background: var(--card-bg);
      border: 1px solid var(--border-color);
      margin-bottom: 16px;
      border-radius: 4px;
    }
    .title { font-size: 18px; font-weight: bold; letter-spacing: 1px; color: #10b981; }
    .status { font-size: 12px; color: #64748b; }
    .grid-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
      gap: 16px;
    }
    .widget-card {
      background: var(--card-bg);
      border: 1px solid var(--border-color);
      border-radius: 4px;
      padding: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.5);
    }
    .widget-header {
      font-size: 13px;
      font-weight: bold;
      border-bottom: 1px dashed var(--border-color);
      padding-bottom: 6px;
      margin-bottom: 10px;
      color: #38bdf8;
      display: flex;
      justify-content: space-between;
    }
    .data-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
    }
    .data-table th, .data-table td {
      padding: 6px 8px;
      text-align: left;
      border-bottom: 1px solid #111827;
    }
    .green { color: #10b981; }
    .red { color: #ef4444; }
    .badge {
      display: inline-block;
      padding: 2px 6px;
      font-size: 10px;
      border-radius: 3px;
      background: #064e3b;
      color: #34d399;
    }
    .clock-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 10px;
    }
    .clock-box {
      background: #030712;
      border: 1px solid #1f2937;
      padding: 8px;
      border-radius: 4px;
    }
    canvas { width: 100%; height: 180px; background: #020305; border: 1px solid #111827; }
  </style>
</head>
<body>
  <header>
    <div>
      <div class="title">TERMINAL // GLOBAL MARKET CANVAS (OFFLINE)</div>
      <div class="status">MODE: OFFLINE LOCAL STANDALONE | TICKS: ACTIVE</div>
    </div>
    <div id="live-clock" style="font-size: 14px; font-weight: bold; color: #f59e0b;"></div>
  </header>

  <div class="grid-container">
    <div class="widget-card">
      <div class="widget-header">
        <span>GLOBAL INDICES</span>
        <span class="badge">LIVE</span>
      </div>
      <table class="data-table">
        <thead>
          <tr><th>INDEX</th><th>PRICE</th><th>CHG %</th></tr>
        </thead>
        <tbody id="indices-body"></tbody>
      </table>
    </div>

    <div class="widget-card">
      <div class="widget-header">
        <span>AAPL 60-SESSION CHART</span>
        <span class="badge" style="background: #1e3a8a; color: #60a5fa;">AAPL $228.50</span>
      </div>
      <canvas id="aapl-canvas"></canvas>
    </div>

    <div class="widget-card">
      <div class="widget-header">
        <span>PRECIOUS METALS & COMMODITIES</span>
        <span class="badge" style="background: #78350f; color: #fcd34d;">SPOT</span>
      </div>
      <table class="data-table">
        <thead>
          <tr><th>ASSET</th><th>PRICE</th><th>24H CHG</th></tr>
        </thead>
        <tbody id="metals-body"></tbody>
      </table>
    </div>

    <div class="widget-card">
      <div class="widget-header">
        <span>WORLD SESSION CLOCKS</span>
        <span class="badge">UTC OVERVIEW</span>
      </div>
      <div class="clock-grid" id="clocks-container"></div>
    </div>
  </div>

  <script>
    const indices = [
      { name: 'S&P 500', price: 5432.80, change: 0.63 },
      { name: 'NASDAQ 100', price: 19842.15, change: 0.94 },
      { name: 'DOW JONES', price: 40120.50, change: -0.11 },
      { name: 'FTSE 100', price: 8214.30, change: 0.23 },
      { name: 'DAX 40', price: 18450.90, change: 0.61 },
      { name: 'NIKKEI 225', price: 38920.00, change: -0.72 }
    ];

    const metals = [
      { name: 'Gold (XAU/USD)', price: 2428.50, change: 0.76 },
      { name: 'Silver (XAG/USD)', price: 29.85, change: 1.43 },
      { name: 'Platinum', price: 982.10, change: -0.44 },
      { name: 'WTI Crude', price: 78.45, change: -1.07 },
      { name: 'Brent Crude', price: 82.30, change: -0.84 }
    ];

    const sessions = [
      { city: 'New York', tz: 'America/New_York', open: 13.5, close: 20 },
      { city: 'London', tz: 'Europe/London', open: 7, close: 15.5 },
      { city: 'Tokyo', tz: 'Asia/Tokyo', open: 0, close: 6 },
      { city: 'Sydney', tz: 'Australia/Sydney', open: 0, close: 6 }
    ];

    function renderIndices() {
      const body = document.getElementById('indices-body');
      body.innerHTML = indices.map(i => \`
        <tr>
          <td><strong>\${i.name}</strong></td>
          <td>\${i.price.toFixed(2)}</td>
          <td class="\${i.change >= 0 ? 'green' : 'red'}">\${i.change >= 0 ? '+' : ''}\${i.change.toFixed(2)}%</td>
        </tr>
      \`).join('');
    }

    function renderMetals() {
      const body = document.getElementById('metals-body');
      body.innerHTML = metals.map(m => \`
        <tr>
          <td><strong>\${m.name}</strong></td>
          <td>$\${m.price.toFixed(2)}</td>
          <td class="\${m.change >= 0 ? 'green' : 'red'}">\${m.change >= 0 ? '+' : ''}\${m.change.toFixed(2)}%</td>
        </tr>
      \`).join('');
    }

    function renderClocks() {
      const container = document.getElementById('clocks-container');
      const now = new Date();
      container.innerHTML = sessions.map(s => {
        const timeStr = now.toLocaleTimeString('en-US', { timeZone: s.tz, hour12: false });
        return \`
          <div class="clock-box">
            <div style="font-size: 11px; color: #94a3b8; font-weight: bold;">\${s.city.toUpperCase()}</div>
            <div style="font-size: 16px; font-weight: bold; color: #38bdf8; margin: 4px 0;">\${timeStr}</div>
            <div style="font-size: 10px;" class="green">TRADING ACTIVE</div>
          </div>
        \`;
      }).join('');
    }

    function updateLiveClock() {
      document.getElementById('live-clock').innerText = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
    }

    function drawAAPLChart() {
      const canvas = document.getElementById('aapl-canvas');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      const w = canvas.width = canvas.clientWidth;
      const h = canvas.height = canvas.clientHeight;

      ctx.clearRect(0, 0, w, h);
      
      // Draw grid
      ctx.strokeStyle = '#111827';
      ctx.lineWidth = 1;
      for (let x = 0; x < w; x += 30) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
      }
      for (let y = 0; y < h; y += 25) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
      }

      // Draw random walk 60 candles simulation
      const barWidth = Math.max(3, (w - 20) / 60);
      let price = 205;
      const prices = [];
      for (let i = 0; i < 60; i++) {
        const delta = (Math.sin(i / 5) * 1.5) + (Math.random() - 0.45) * 2;
        price += delta;
        prices.push(price);
      }

      const minP = Math.min(...prices) - 2;
      const maxP = Math.max(...prices) + 2;

      prices.forEach((p, i) => {
        const x = 10 + i * barWidth;
        const y = h - 20 - ((p - minP) / (maxP - minP)) * (h - 40);
        const openY = y + (i % 2 === 0 ? 3 : -3);
        const isUp = p >= openY;

        ctx.strokeStyle = isUp ? '#10b981' : '#ef4444';
        ctx.fillStyle = isUp ? '#10b981' : '#ef4444';

        ctx.beginPath();
        ctx.moveTo(x + barWidth / 2, y - 4);
        ctx.lineTo(x + barWidth / 2, y + 4);
        ctx.stroke();

        ctx.fillRect(x, Math.min(y, openY), Math.max(2, barWidth - 1), Math.max(2, Math.abs(y - openY)));
      });
    }

    // Tick Loop
    setInterval(() => {
      indices.forEach(i => { i.price += (Math.random() - 0.49) * 2; });
      metals.forEach(m => { m.price += (Math.random() - 0.49) * 0.5; });
      renderIndices();
      renderMetals();
      renderClocks();
      updateLiveClock();
    }, 1000);

    renderIndices();
    renderMetals();
    renderClocks();
    updateLiveClock();
    drawAAPLChart();
    window.addEventListener('resize', drawAAPLChart);
  </script>
</body>
</html>`;

  zip.file('README.md', readmeContent);
  zip.file('index.html', standaloneHtml);
  zip.file('config/layout_backup.json', layoutJson);

  const content = await zip.generateAsync({ type: 'blob' });
  
  // Trigger download
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = `terminal_canvas_offline_${new Date().toISOString().slice(0, 10)}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
